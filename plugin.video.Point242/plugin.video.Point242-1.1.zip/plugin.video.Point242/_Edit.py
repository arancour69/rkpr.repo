import xbmcaddon

MainBase ='https://pastebin.com/raw/7b2m0QV3'
addon = xbmcaddon.Addon('plugin.video.Point242')
import xbmc

xbmc.executebuiltin('XBMC.ReloadSkin()')
xbmc.executebuiltin('ActivateWindow(124)')
xbmc.executebuiltin("Action(Up)")
xbmc.executebuiltin("Action(Up)")
xbmc.executebuiltin("Action(Up)")
xbmc.executebuiltin("Action(Select)")


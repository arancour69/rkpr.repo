import xbmcaddon

MainBase = 'http://buckymedia.ru/redemption/addon/home.txt'
addon = xbmcaddon.Addon('plugin.video.Redemption')
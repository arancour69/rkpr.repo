import xbmcaddon

MainBase ='https://pastebin.com/raw/acr8EKEi'
addon = xbmcaddon.Addon('plugin.video.cinebrkodi')
